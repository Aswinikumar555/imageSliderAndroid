package com.example.randomizer

import android.os.Bundle
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.denzcoskun.imageslider.ImageSlider
import com.denzcoskun.imageslider.models.SlideModel
import java.util.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//        val rollButton = findViewById<Button>(R.id.rollButton);
//        val resulrTextView  = findViewById<TextView>(R.id.resulrTextView);
//        val seekBar = findViewById<SeekBar>(R.id.seekBar)
//
//        rollButton.setOnClickListener {
//            val rand = Random().nextInt(seekBar.progress)
//            resulrTextView.text = rand.toString()
//        }

        val imageSlider = findViewById<ImageSlider>(R.id.imageSlider)
        val sliderModels: MutableList<SlideModel> = ArrayList()
        sliderModels.add(SlideModel("https://thumbs.dreamstime.com/b/waterfalls-nature-landscape-blue-ridge-14800361.jpg", "1 image "))
        sliderModels.add(SlideModel("https://thumbs.dreamstime.com/b/waterfalls-nature-landscape-blue-ridge-14800361.jpg", "2 image "))
        sliderModels.add(SlideModel("https://thumbs.dreamstime.com/b/waterfalls-nature-landscape-blue-ridge-14800361.jpg", "3 image "))
        sliderModels.add(SlideModel("https://thumbs.dreamstime.com/b/waterfalls-nature-landscape-blue-ridge-14800361.jpg", "4 image "))

        imageSlider.setImageList(sliderModels, true)
    }
}